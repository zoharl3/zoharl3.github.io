
One-ring brute-force Linf Field-alignment optimization

The main function is 
double solveLinf_C (  int N,  double p[63][2],  double uv[42][2],  double R[21][2][2],  double xstar[2])

The file oneringopt.cpp entirely auto-generated from maple.

Functions test1-test4 run several tests, results of which can be compared 
either to Maple, or matlab script (also auto-generated) oneringopt.m

Parameters: 
21 = NUM_TRIANGLES = N: arbitrarily picked max number of triangles in the neighborhood (fixed size is used is due to limitations of Maple C code generator)

p[3*N][2]:  coordinates of mesh triangle vertices in an arbirtary 2D coordinate system in the plane of triangle, 
                       for each triangle in sequence, listed ccw for each triangle starting with the central vertex. 
                       for a closed ring
                       p01, p11 p21, p02, p22 p32, ... p0N, pNN p1N, where p0i is the central vertex in the coord system of triangle i,  
                       and generally pij is the vertex pi of the ring in the coord system of triangle j. 
                       for an open ring, the end of the array has the form p0N p(N-1)N, pNN
                        
uv[2*N][2]: param positions for two fixed vertices of each triangle on the boundary of 1-ring
                     (assume no seams, so vertices have the same coords in two triangles they may belong to).
                     if uvi is the uv position of vertex i, i=1..N, then  
                     uv1, uv2, uv2, uv3, uv3... uvN, uvN uv1 for closed neighborhood, and  uv1, uv2 uv2, ... uv(N-1) uv(N-1), uvN                  
                     for open 1-ring

R[N][2][2]: rotations, stored as 2x2 matrices w.r.t. the same 2d  coordinate system on the triangle, one per triangle

xstar[2]:            output variable, returns optimal point 

return value:   minimal distortion value |J - R|^2 


function testMain() runs four tests, that print out solutions. 
To validate, run oneringopt.m, and compare results to the results
testMain() prints. 

Automatically generated files: 
oneringopt.cpp -- C version of one-ring optimization + test functions 
onergingopt.m -- Matlab version of the same test data + code to run 
these examples in cvx 





