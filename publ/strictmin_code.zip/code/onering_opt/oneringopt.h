
#pragma once

static const int c_1ring_max_num_triangles = 51;

// See readme.txt in the directory
double solveLinf_C(int nF, double P[3*c_1ring_max_num_triangles][2], double UVs[2*c_1ring_max_num_triangles][2], double Rs[c_1ring_max_num_triangles][2][2], double xstar[2]);

