extern void testMain(); 
int main() { 
       testMain(); 
}