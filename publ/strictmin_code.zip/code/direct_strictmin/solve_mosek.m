
function [success, x, t] = solve_mosek(n, m, bt, kl, Ceq, deq, Cineq)
    tic;
    p = MosekProblemManager;
    
    G2 = [Cineq.j11mat; Cineq.j21mat; Cineq.j12mat; Cineq.j22mat];
    ind = [1:4:4*m, 2:4:4*m, 3:4:4*m, 4:4:4*m];
    I = speye(4*m);
    G = I(ind,:)'*G2;
    
    t_ind = p.add_vars(1);
    x_ind = p.add_vars(n);

    p.add_eq(Ceq, x_ind, deq);    
    
    dd_ind = p.add_vars(4*m);
    dd_ind4 = reshape(dd_ind', 4, m)';
    R = Cineq.se';
    % I*dd = G*x - R
    p.add_eq([speye(4*m) -G], [dd_ind, x_ind], -R(:));

    ind0 = find(bt==0); 
    sz0 = numel(ind0);
    if sz0 > 0
        k_ind = p.add_vars(sz0);
        % k = kl(ind0)
        p.add_eq(speye(sz0), k_ind, kl(ind0));
        sub0 = zeros(1,sz0*5);
        sub0(1,1:5:end) = k_ind;
        for i = 2:5
            sub0(1,i:5:end) = dd_ind4(ind0, i-1);
        end
        % ||dd(ind0)|| < k
        p.add_cone(sub0, 1:5:(sz0*5));
    end
    
    ind1 = find(bt==1);
    sz1 = numel(ind1);
    sub1 = zeros(1,sz1*5);
    sub1(1) = t_ind;
    % cones must have unique vars. duplicate t.
    t_dup_ind = p.add_vars(sz1-1);
    sub1(1,6:5:end) = t_dup_ind;
    p.add_eq([speye(sz1-1), -ones(sz1-1,1)], [t_dup_ind, 1], []);
    for i = 2:5
        sub1(1,i:5:end) = dd_ind4(ind1, i-1);
    end
    % ||dd(ind1)|| < t
    p.add_cone(sub1, 1:5:(sz1*5));
    
    p.set_obj(1, 1);
    
    disp('finished init');
    toc;
    [r, res] = p.run();
    t = abs(res.sol.itr.xx(t_ind));
    x = res.sol.itr.xx(x_ind);
    success = r == 0 || r == 10006;
end
