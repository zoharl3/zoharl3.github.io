
function [success, x, t] = solve_yalmip_dual(n, m, bt, kl, Ceq, deq, Cineq)
    tic;
    nc = numel(deq);

    mu1 = sdpvar(nc, 1, 'full');
    u = sdpvar(4, m, 'full');
    lam = sdpvar(m, 1, 'full');

    r = Cineq.se';
    
    Objective = -mu1'*deq - u(:)'*r(:);

    c = [1; zeros(n,1)];
    if 1
        G = sparse(4*m, n);
        G(1:4:4*m,:) = Cineq.j11mat;
        G(2:4:4*m,:) = Cineq.j21mat;
        G(3:4:4*m,:) = Cineq.j12mat;
        G(4:4:4*m,:) = Cineq.j22mat;
    else
        G2 = [Cineq.j11mat; Cineq.j21mat; Cineq.j12mat; Cineq.j22mat];
        ind = [1:4:4*m, 2:4:4*m, 3:4:4*m, 4:4:4*m];
        I = speye(4*m);
        G = I(ind,:)'*G2;
    end
    Gtu = G' * u(:);
    dL = c + [0; Ceq'*mu1] + [0; Gtu] - sum(lam) * c;
    
    eq_con = dL == 0;
    cones = [lam'; u];
    
    Constraints = [eq_con:'tx'; cone(cones)];
    
    options = sdpsettings('verbose',2,'solver','mosek-sdp','savesolverinput',1,'debug',1,'showprogress',1,'saveduals',1,'savesolveroutput',1);
    disp('finished init');
    toc;
    sol = solvesdp(Constraints, Objective, options);
    if sol.problem == 0
        success = 1;
        tx = dual(Constraints('tx'));
        t = abs(tx(1));
        x = tx(2:end);
    else
        success = 0;
        display('Hmm, something went wrong!');
        sol.info
        yalmiperror(sol.problem)
    end
    
end
