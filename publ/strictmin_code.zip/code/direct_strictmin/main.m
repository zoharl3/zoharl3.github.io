
clc; clear;

% Load data. Choose below one of two data sets.
% The data contains initilization already of seamless global parametrization [Bommes09]. Namely, the field is given and the surface is cut.
%load data1; % hand
load data2; % dented plane 11x11, without cones.

% m, n - number of facets and vertices
% bt, kl - same initial arrays as in strictmin().
% Ceq, deq - rhs and lhs of equality constraints. Represent the seamless and positional constraints. In the absence of cones, these are just constraints fixing a point, of the form Ceq = [1 0.. 0; 0 1 0..0] deq = [0; 0].
% Cineq.j11mat .. Cineq.j22mat - where the product Cineq.j11mat*x gives the element (1,1) of the Jacobian for each facet.
% Cineq.se - each row is a 2x2 matrix representing the target frame on a facet.
% x - return value, UV coordinates.
%
% Choose below what to run (comment/uncomment).
%
% Linf
%solve_cvx(n, m, bt, kl, Ceq, deq, Cineq);
%solve_yalmip(n, m, bt, kl, Ceq, deq, Cineq);
%solve_yalmip_dual(n, m, bt, kl, Ceq, deq, Cineq);
%solve_mosek(n, m, bt, kl, Ceq, deq, Cineq);
%
% direct strict minimizer
strictmin(n, m, Ceq, deq, Cineq);

