
% mosek doc, section 9.6: http://docs.mosek.com/7.0/toolbox/A_guided_tour.html
% based on Roi's code

classdef MosekProblemManager < handle
    %MOSEKPROBLEMMANAGER a helper class for holding a mosek problem
    %   Detailed explanation goes here
    
    properties
        c        
        a
        blc        
        buc
        blx
        bux        
        cones
    end
    
    methods
        function obj = MosekProblemManager
            obj.init();
        end
    end
    
    methods(Access = public)
        
        function init(obj)
            obj.a = [];
            obj.buc = [];
            obj.blc = [];
            obj.bux = [];
            obj.blx = [];
            obj.c = [];
            obj.cones = struct('sub',[],'subptr',[],'type',[]);        
        end
        
        % set objective, should be call last
        function set_obj(obj, coeff, ind)
            obj.c = zeros(1, size(obj.a,2));
            obj.c(ind) = coeff;
        end
        
        % Add NV variables to the problem
        function ind = add_vars(obj,NV)
            % ind: the indices of the new variables
            ind = size(obj.a,2)+(1:NV);
            obj.a = [obj.a,zeros(size(obj.a,1),NV)];
            %obj.blx = [obj.blx, -Inf*ones(1,NV)];
            %obj.bux = [obj.bux, Inf*ones(1,NV)];
        end
        
        function EqInd = add_eq(obj,M,x,b)
            % add M*x==b to the problem
            % x - var indices that get affected
            % M - sub matrix, where the number of columns is the size of x
            obj.a = [obj.a;sparse(size(M,1),size(obj.a,2))];
            obj.a(end-size(M,1)+1:end,x) = M;
            if isempty(b)
                b = zeros(size(M,1),1);
            end
            obj.buc = [obj.buc;b];
            obj.blc = [obj.blc;b];
            EqInd = size(obj.a,1)-size(M,1):size(obj.a,1);
        end
        
        function IneqInd = add_ineq(obj,M,x,b)
            % add M*x<b to the problem
            obj.a = [obj.a;sparse(size(M,1),size(obj.a,2))];
            obj.a(end-size(M,1)+1:end,x) = M;
            if isempty(b)
                b = zeros(size(M,1),1);
            end
            obj.buc = [obj.buc;b];
            obj.blc = [obj.blc;nan(size(b))];
            IneqInd = size(obj.a,1)-size(M,1):size(obj.a,1);
        end
        
        function add_cone(obj,sub,subptr,type)
            % types: res.symbcon.MSK_CT_QUAD=0, res.symbcon.MSK_CT_RQUAD=1
            if nargin < 4
                type = 0;
            end
            obj.cones.type = [obj.cones.type, type*ones(1,numel(subptr))];            
            obj.cones.subptr = [obj.cones.subptr, numel(obj.cones.sub)+subptr];            
            obj.cones.sub = [obj.cones.sub, sub];            
        end
        
        function [r,res] = run(obj)
            assert(size(obj.a,2) == numel(obj.c));
            
            p = {};
            p.c = obj.c;
            p.a = obj.a;
            p.blc = obj.blc;
            p.buc = obj.buc;
            p.blx = obj.blx;
            p.bux = obj.bux;
            p.cones = obj.cones;
            
            [r,res] = mosekopt('minimize', p);
        end
    end
end


