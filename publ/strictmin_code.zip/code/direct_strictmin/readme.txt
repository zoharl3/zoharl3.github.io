
data?.mat: Two datasets of different size.

main.m: main script.

% Four different implementations of Linf minimizer. The primal problem formulation is slower than the dual formulation.
solve_cvx.m: Solves one iteration using cvx (which solves the dual problem).
solve_yalmip.m: Solves one iteration using yalmip.
solve_yalmip_dual.m: Solves one iteration of the dual problem using yalmip.
solve_mosek.m: Solves one Linf iteration of the primal problem using mosek.

% Direct strict minimizer
strictmin.m: Iteratively calls one of the two above (change in the strictmin which one to use), where each iteration has a lower maximum distortion than the previous.
