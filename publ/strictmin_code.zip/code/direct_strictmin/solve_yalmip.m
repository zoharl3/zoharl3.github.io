
function [success, x, t] = solve_yalmip(n, m, bt, kl, Ceq, deq, Cineq)
    x = sdpvar(n, 1,'full');
    t = sdpvar(1);

    Objective = t;
        
    J = [Cineq.j11mat * x, Cineq.j21mat * x, Cineq.j12mat * x, Cineq.j22mat * x];
    dd = J - Cineq.se;
    
    if ~isempty(Ceq)
        eq_con = Ceq * x == deq;
    end

    dd = dd';
    cones = [t * bt(bt==1)' kl(bt==0)'; dd(:,bt==1) dd(:,bt==0)];
    
    Constraints = [eq_con; cone(cones)];
    
    options = sdpsettings('verbose',2,'solver','mosek-sdp','savesolverinput',1,'debug',1,'showprogress',1);
    sol = solvesdp(Constraints, Objective, options);
    if sol.problem == 0
        success = 1;
    else
        success = 0;
        display('Hmm, something went wrong!');
        sol.info
        yalmiperror(sol.problem)
    end
   
end
