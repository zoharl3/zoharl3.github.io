
function [success, x] = strictmin(n, m, Ceq, deq, Cineq)
    bt = ones(m,1);
    kl = zeros(m,1);
    
    nIter = 1;
    while 1
        kstep = 1e-3;
        
        % Choose Linf solver below (comment/uncomment).
        %[success, x, t] = solve_cvx(n, m, bt, kl, Ceq, deq, Cineq);
        %[success, x, t] = solve_yalmip(n, m, bt, kl, Ceq, deq, Cineq);
        %[success, x, t] = solve_yalmip_dual(n, m, bt, kl, Ceq, deq, Cineq);
        [success, x, t] = solve_mosek(n, m, bt, kl, Ceq, deq, Cineq);
        
        if ~success; break; end
        
        [bBreak, kl, bt] = update_bounds(Cineq, x, bt, kl, t, nIter, kstep);
        if bBreak; break; end
        nIter = nIter + 1;
    end
end

function [bBreak, kl, bt] = update_bounds(Cineq, x, bt, kl, t, nIter, kstep)
    min_bound = .1;
    
    J = [Cineq.j11mat * x, Cineq.j21mat * x, Cineq.j12mat * x, Cineq.j22mat * x];
    dd = J - Cineq.se;
    %ndd = norms(dd, 2, 2);
    ndd = sqrt(sum(dd.^2, 2));

    tmax = max(ndd(bt==1)) - kstep;
    ind = find(ndd >= tmax);
    kl(ind) = ndd(ind) + 1e-4;
    bt(ind) = 0;
    
    fprintf(1, 'nIter=%d, bt=%d, t=%f t^2=%f, tmax=%f tmax^2=%f, max_ndd=%f max_ndd^2=%f\n', nIter, sum(bt==1), t, t^2, tmax, tmax^2, max(ndd), max(ndd.^2));

    maxIter = 1e6;
    bBreak = 0;
    if nIter >= maxIter || tmax < sqrt(min_bound) || sum(bt) == 0 
        bBreak = 1;
    end
end

