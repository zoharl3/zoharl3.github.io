
function [success, x, t] = solve_cvx(nvars, m, bt, kl, Ceq, deq, Cineq)
    cvx_clear
    cvx_solver mosek
    cvx_begin
        cvx_precision([sqrt(eps), sqrt(eps), 1-eps]); % .999 which is the max value, since we know the problem shouldn't fail.

        variable x(nvars)
        variable t(1)

        minimize( t );

        subject to
            if ~isempty(Ceq)
                Ceq * x == deq;
            end

            J = [Cineq.j11mat * x, Cineq.j21mat * x, Cineq.j12mat * x, Cineq.j22mat * x];
            dd = J - Cineq.se;
            ndd = norms(dd, 2, 2);

            ndd(bt==1) <= t * bt(bt==1);
            ndd(bt==0) <= kl(bt==0);
    cvx_end
    success = strcmp(cvx_status, 'Solved') | strcmp(cvx_status, 'Inaccurate/Solved');                    
end
