
direct_strictmin - matlab example of Linf and direct strict minimizer.

onering_opt - C++ code to optimize Linf on a 1-ring.

