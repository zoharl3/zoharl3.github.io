
Drawings of the seam graphs and polygons of all the (10,177) negative fields for genus 2-5.
A vertex label consists of the vertex id, index, and iset id.

histograms.txt contains the cone-index histograms. Each line corresponds to a field. The left most bin is index -0.25, and the bins decrease in index to the right in steps of -0.25.
