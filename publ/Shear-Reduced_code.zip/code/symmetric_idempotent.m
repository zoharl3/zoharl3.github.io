
function N = symmetric_idempotent(n)

N = 0.5 * ( eye(n^2) + commutation_matrix(n, n) );

