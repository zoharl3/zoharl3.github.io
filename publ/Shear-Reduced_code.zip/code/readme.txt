
Code to test the derivatives against Matlab symbolic toolbox.

Run: run_test_derivatives.m

