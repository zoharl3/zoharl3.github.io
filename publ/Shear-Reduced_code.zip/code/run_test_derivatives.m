
function run_test_derivative()
    clc; clear;
    
    %rmpath('c:\prj\confstruct\scripts\'); % for testing dependencies

    t = TestDerivatives(); 
    t.main();
end
