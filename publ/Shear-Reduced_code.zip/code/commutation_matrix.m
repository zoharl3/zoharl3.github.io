
function Y = commutation_matrix(m, n)

if nargin == 1
    n = m;
end

A = reshape(1:m*n, [m, n]); % initialize a matrix of indices
A = A'; % Transpose it
A = A(:); % vectorize the required indices
Y = eye(m*n); % Initialize an identity matrix
Y = Y(A, :); % Re-arrange the rows of the identity matrix
