
classdef TestDerivatives < matlab.mixin.Copyable
properties
    K32
    N2
    
    G
    G1
    G2
    
    J_
    J1_
    J2_

    Rm
    Rk

    M_
    m_

    n

    iJ_
    A
end

methods

function o = TestDerivatives()
    o.n = 4; % 4..6; number of vertices in a hinge of psi
    o.A = rand(2); % a frame
    o.init();
end

function init(o)
    o.K32 = commutation_matrix( 3, 2 );
    o.N2 = symmetric_idempotent( 2 );
    
    if 0 % a specific example
        % for phi
        D1 = [-1.0000    1.0000         0];
        D2 = [-1.0000         0    1.0000];
        o.G = [D1; D2];

        % for psi
        D1 = [
            -1         1        0         0
             0         1       -1         0
        ];
        D2 = [
            -1         0        1         0
             0        -1       -1         1
        ];
        o.G1 = [D1(1,:); D2(1,:)];
        o.G2 = [D1(2,:); D2(2,:)];
        o.Rm = [1  0; 0  1];
        o.Rk = [0 -1; 1  0];
    else % symbolic
        % phi
        nv = 3; % #vertices
        g = sym('g', [1 2*nv], 'real')';
        o.G = reshape(g, 2, nv);

        % psi
        nv = o.n;
        g1 = sym('g1', [1 2*nv], 'real')';
        o.G1 = reshape(g1, 2, nv);

        g2 = sym('g2', [1 2*nv], 'real')';
        o.G2 = reshape(g2, 2, nv);

        rm = sym('rm', [1 4], 'real')';
        o.Rm = reshape(rm, 2, 2);
    
        rk = sym('rk', [1 4], 'real')';
        o.Rk = reshape(rk, 2, 2);
    end
end

% check if a symbolic expression is zero
function f = check_zero( o, ex )
    if 1 % subs
        x = symvar(ex);
        x0 = rand( size(x) );
        f = double( subs(ex, x, x0) );
    elseif 0
        f = numden( ex );
    else
        f = simplify( ex );
    end
end

function test_phi(o)
    nv = 3; % #vertices
    x = sym('x', [1 2*nv], 'real')';
    X = reshape(x, nv, 2);

    phi = o.phi( X )
    
    fprintf( '\n-------------------\n\n' )

    Dphi = o.Dphi( X ) % ours
    Dphi2 = jacobian( phi, x ) % symbolic
    disp( 'Dphi - Dphi2 =' );
    disp( o.check_zero( Dphi - Dphi2 ) ) % the difference between the two

    fprintf( '\n-------------------\n\n' )

    Hphi = o.Hphi( X ); % ours
    disp( 'Hphi = ' );
    %disp( Hphi ); % slow
    Hphi2 = hessian( phi, x ) % symbolic
    disp( 'Hphi - Hphi2 =' );
    disp( o.check_zero( Hphi - Hphi2 ) );
end

function test_psi(o)
    nv = o.n;
    x = sym('x', [1 2*nv], 'real')';
    X = reshape(x, nv, 2);

    psi = o.psi( X )
    
    fprintf( '\n-------------------\n\n' )

    Dpsi = o.Dpsi( X )
    Dpsi2 = jacobian( psi, x )
    disp( 'Dpsi - Dpsi2 =' );
    disp( o.check_zero( Dpsi - Dpsi2 ) );

    fprintf( '\n-------------------\n\n' )

    Hpsi = o.Hpsi( X );
    disp( 'Hpsi = ' );
    %disp( Hpsi ); % slow
    Hpsi2 = hessian( psi, x )
    disp( 'Hpsi - Hpsi2 =' );
    disp( o.check_zero( Hpsi - Hpsi2 ) );
end

function test_xi(o)
    nv = 3;
    x = sym('x', [1 2*nv], 'real')';
    X = reshape(x, nv, 2);

    xi = o.xi( X )
    
    fprintf( '\n-------------------\n\n' )

    Dxi = o.Dxi( X )
    Dxi2 = jacobian( xi, x )
    disp( 'Dxi - Dxi2 =' );
    disp( o.check_zero( Dxi - Dxi2 ) );

    fprintf( '\n-------------------\n\n' )

    Hxi = o.Hxi( X );
    disp( 'Hxi = ' );
    %disp( Hxi ); % slow
    Hxi2 = hessian( xi, x )
    disp( 'Hxi - Hxi2 =' );
    disp( o.check_zero( Hxi - Hxi2 ) );
end

function main(o)
    fprintf( 'Shear\n' )
    test_phi(o)

    fprintf( '\n-------------------\n\n' )
    fprintf( 'Smoothness\n' )
    test_psi(o)

    fprintf( '\n-------------------\n\n' )
    fprintf( 'Frame alignment\n' )
    test_xi(o)
end

%%%%%%
% smoothness
function f = psi(o, X)
    f = o.psi1(X) + o.psi2(X);
end

function D = Dpsi(o, X)
    DJ1 = kron(o.G1, eye(2)) * commutation_matrix(o.n, 2);
    DJ2 = kron(o.Rk*o.G2, eye(2)) * kron(eye(4), o.Rm') * commutation_matrix(o.n, 2);
    Dalpha = ( kron(o.G1, eye(2)) - kron(o.Rk*o.G2, eye(2)) * kron(eye(4), o.Rm') ) * commutation_matrix(o.n, 2);
    Deta_alpha = 2*vec(o.alpha(X))';
    Deta_X = Deta_alpha * Dalpha;

    Dpsi1_X = Deta_X * o.mu( o.J1 ) + o.eta(X) * o.Dmu_J_X( o.J1, DJ1 );
    Dpsi2_X = Deta_X * o.mu( o.J2 ) + o.eta(X) * o.Dmu_J_X( o.J2, DJ2 );

    D = Dpsi1_X + Dpsi2_X;
end

function H = Hpsi(o, X)
    DJ1 = kron(o.G1, eye(2)) * commutation_matrix(o.n, 2);
    DJ2 = kron(o.Rk*o.G2, eye(2)) * kron(eye(4), o.Rm') * commutation_matrix(o.n, 2);
    Dalpha = ( kron(o.G1, eye(2)) - kron(o.Rk*o.G2, eye(2)) * kron(eye(4), o.Rm') ) * commutation_matrix(4, 2);
    Deta_alpha = 2*vec(o.alpha(X))';
    Deta_X = Deta_alpha * Dalpha;

    Heta_X = Dalpha' * 2 * eye(4) * Dalpha;

    Hpsi1_X = bsym( Heta_X * o.mu( o.J1 ) + 2*Deta_X' * o.Dmu_J_X( o.J1, DJ1 ) + o.eta(X) * o.Hmu_J_X( o.J1, DJ1 ) );
    Hpsi2_X = bsym( Heta_X * o.mu( o.J2 ) + 2*Deta_X' * o.Dmu_J_X( o.J2, DJ2 ) + o.eta(X) * o.Hmu_J_X( o.J2, DJ2 ) );

    H = Hpsi1_X + Hpsi2_X;
end

%%%%%%
function H = Hmu_J_X(o, J, DJ)
    Dbeta_J = ( vec( det(J) * inv(J)' ) )';
    Dmu_beta = -o.beta(J)^(-2);

    Hbeta_J = det(J) * commutation_matrix(2, 2) * kron(inv(J), eye(2))' * (vec(eye(2))*vec(eye(2))' - eye(4)) * kron(eye(2), inv(J));
    Hmu_beta = 2 / o.beta(J)^3;
    Hmu_J = Dbeta_J' * Hmu_beta * Dbeta_J + Dmu_beta * Hbeta_J;
    H = DJ' * Hmu_J * DJ;
end

function D = Dmu_J_X(o, J, DJ)
    Dbeta_J = ( vec( det(J) * inv(J)' ) )';
    Dmu_beta = -o.beta(J)^(-2);
    Dmu_J = Dmu_beta * Dbeta_J;
    D = Dmu_J * DJ;
end

function f = psi2(o, X)
    f = o.eta(X) * o.mu( o.J2(X) );
end

function f = psi1(o, X)
    f = o.eta(X) * o.mu( o.J1(X) );
end

function f = mu(o, J)
    f = 1 / o.beta(J);
end

function f = beta(o, J)
    f = det(J);
end

function f = eta(o, X)
    a = vec(o.alpha(X));
    f = dot(a, a);
end

function f = alpha(o, X)
    f = o.J1(X) - o.J2(X);
end

function f = J1(o, X)
    % caching
    if nargin == 1 && ~isempty(o.J1_)
        f = o.J1_;
        return;
    end
    
    f = (o.G1*X)';
    o.J1_ = f;
end

function f = J2(o, X)
    if nargin == 1 && ~isempty(o.J2_)
        f = o.J2_;
        return;
    end
    
    f = o.Rm' * (o.G2*X)' * o.Rk';
    o.J2_ = f;
end

%%%%%%
% shear
function f = phi(o, X)
    J = o.J( X );
    M = o.M( J );
    if 0 % test inverse M
        M = inv( M );
    end
    f = o.m12(M)^2 / ( o.m11(M) * o.m22(M) );
end

function D = Dphi(o, X)
    DJ_X = kron(o.G, eye(2)) * o.K32;
    DM_J = 2 * o.N2 * kron( o.J, eye(2) );
    Dm_M = [vec(o.E(1, 1, 2)')'; vec(o.E(1, 2, 2)')'; vec(o.E(2, 2, 2)')']; 
    Dphi_m = o.Dphi_m( o.m( o.M() ) );

    D = Dphi_m * Dm_M * DM_J * DJ_X;
end

function H = Hphi(o, X)
    DJ_X = kron(o.G, eye(2)) * o.K32;
    DM_J = 2 * o.N2 * kron( o.J, eye(2) );
    Dm_M = [ vec(o.E(1, 1, 2)')'; vec(o.E(1, 2, 2)')'; vec(o.E(2, 2, 2)')' ];
    Dphi_m = o.Dphi_m( o.m( o.M() ) );

    DM_X = DM_J * DJ_X;
    Dm_X = Dm_M * DM_X;

    cE = [
        kron( eye(2), o.E(1,1,2) ); 
        kron( eye(2), o.E(2,1,2) ); 
        kron( eye(2), o.E(1,2,2) ); 
        kron( eye(2), o.E(2,2,2) )
        ];
    HM_J = bsym( 2 * cE );
    HM_X = kron( eye(4), DJ_X )' * HM_J * DJ_X;
    Hm_X = kron( Dm_M, eye(6) ) * HM_X;

    H = Dm_X' * o.Hphi_m( o.m ) * Dm_X + kron( Dphi_m, eye(6) ) * Hm_X;
end

%%%%%%
% frame alignment
function f = xi(o, X)
    J = o.J( X );
    o.iJ( J );
    iA = inv( o.A );

    f = 0.5*( sqnormf( J - o.A ) + sqnormf( o.iJ - iA ) );
end

function D = Dxi(o, X)
    J = o.J( X );
    iA = inv( o.A );
    
    DJ_X = kron( o.G, eye(2) ) * o.K32;
    DiJ_X = -kron( o.iJ', o.iJ ) * DJ_X;
    
    D = vec( J - o.A )' * DJ_X + vec( o.iJ - iA )' * DiJ_X;
end

function H = Hxi(o, X)
    iA = inv( o.A );
    
    DJ_X = kron( o.G, eye(2) ) * o.K32;
    DiJ_X = -kron( o.iJ', o.iJ ) * DJ_X;
    
    HiJ_J = bsym( [o.Hc_iJ(1,1); o.Hc_iJ(2,1); o.Hc_iJ(1,2); o.Hc_iJ(2,2)] );
    HiJ_X = kron( eye(4), DJ_X )' * HiJ_J * DJ_X;

    H = DJ_X'*DJ_X + DiJ_X'*DiJ_X + kron( vec( o.iJ - iA )', eye(6) ) * HiJ_X;
end

%%%%%%
function H = Hc_iJ(o, i, j)
    H = 2*commutation_matrix(2)' * kron(o.iJ * o.E(i, j, 2) * o.iJ, eye(2))' * kron(eye(2), o.iJ);
end

function f = Dphi_m(o, m) 
    cm = num2cell( m );
    [m11, m12, m22] = deal( cm{:} );

    f = [ -m12^2/(m11^2*m22), (2*m12)/(m11*m22), -m12^2/(m11*m22^2) ];
end

function H = Hphi_m(o, m) 
    cm = num2cell(m);
    [m11, m12, m22] = deal( cm{:} );
    
    H = [
        [ (2*m12^2)/(m11^3*m22), -(2*m12)/(m11^2*m22),   m12^2/(m11^2*m22^2)]
        [  -(2*m12)/(m11^2*m22),          2/(m11*m22),  -(2*m12)/(m11*m22^2)]
        [   m12^2/(m11^2*m22^2), -(2*m12)/(m11*m22^2), (2*m12^2)/(m11*m22^3)]
        ];
end

function f = J(o, X)
    if nargin == 1 && ~isempty(o.J_)
        f = o.J_;
        return;
    end
    
    f = X' * o.G';
    o.J_ = f;
end

function f = iJ(o, J)
    if nargin == 1 && ~isempty(o.iJ_)
        f = o.iJ_;
        return;
    end
    
    f = inv(J);
    o.iJ_ = f;
end

function f = M(o, J)
    if nargin == 1 && ~isempty(o.M_)
        f = o.M_;
        return;
    end
    
    f = J*J';
    o.M_ = f;
end

function f = m11(o, M)
    f = trace(o.E(1, 1, 2) * M);
end

function f = m12(o, M)
    f = trace(o.E(1, 2, 2) * M);
end

function f = m22(o, M)
    f = trace(o.E(2, 2, 2) * M);
end

function f = m(o, M)
    if nargin == 1 && ~isempty(o.m_)
        f = o.m_;
        return;
    end
    
    f = [
        o.m11(M);
        o.m12(M);
        o.m22(M) 
        ];
    o.m_ = f;
end

function f = E(o, i, j, n)
    I2 = eye( 2 );
    ei = I2( :, i );
    ej = I2( :, j );
    f = ej*ei';
end

end % methods

end % classdef

function f = sqnormf( x )
    f = dot( x(:), x(:) );
end

