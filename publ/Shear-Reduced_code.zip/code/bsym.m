
% Block matrix symmetrization
function S = bsym( A )

[m, n] = size(A);

bTranspose = 0;
if ( m < n )
    A = A';
    bTranspose = 1;
end

assert( mod(m, n) == 0 );
for i = 1:(m/n)
    A((n*(i-1)+1):i*n, :) = ( A((n*(i-1)+1):i*n, :) + A((n*(i-1)+1):i*n, :)' ) / 2;
end

if bTranspose
    A = A';
end

S = A;
